DEADLY COUNTDOWN - ANDROID PROJECT

Day la project Android Studio boc game HTML/CSS/JavaScript bang Android WebView.
Da them nut dieu khien cam ung co ban cho dien thoai.

CACH XUAT APK:
1. Cai Android Studio va Android SDK (API 35).
2. Mo thu muc DeadlyCountdown trong Android Studio.
3. Cho Gradle Sync hoan tat.
4. Chon Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug nam tai app/build/outputs/apk/debug/app-debug.apk.

Luu y: Moi truong tao file hien tai khong co Android SDK/Gradle nen chua the bien dich APK tai day.
Du an nay can Android Studio de tao APK. Package id: com.deadlycountdown.game


XUAT APK TU DONG TREN GITHUB (KHONG CAN CAI ANDROID STUDIO):
1. Tao repository GitHub moi va upload toan bo noi dung thu muc deadly_android len repository.
2. Vao tab Actions.
3. Chon workflow "Build Deadly Countdown APK".
4. Bam Run workflow (hoac push code len nhanh main/master).
5. Cho build xong, vao ket qua run va tai artifact "DeadlyCountdown-debug-apk".
6. Giai nen artifact, ben trong co app-debug.apk de cai tren Android.

Workflow su dung Java 17, Gradle 8.9 va Android SDK. APK tao ra la ban debug.
