// ===== CẤU HÌNH & TRẠNG THÁI =====
const screens = {
  menu: document.getElementById('menu-screen'),
  guide: document.getElementById('guide-screen'),
  setting: document.getElementById('setting-screen'),
  game: document.getElementById('game-screen')
};

function showScreen(name) {
  Object.values(screens).forEach(s => s.classList.remove('active'));
  screens[name].classList.add('active');
}

// Chọn nhân vật
let selectedRole = 'survivor';
document.querySelectorAll('.char-card').forEach(card => {
  card.addEventListener('click', () => {
    document.querySelectorAll('.char-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
    selectedRole = card.dataset.role;
  });
});

// Điều hướng nút Menu
document.getElementById('btn-guide').onclick = () => showScreen('guide');
document.getElementById('btn-back-guide').onclick = () => showScreen('menu');
document.getElementById('btn-setting').onclick = () => showScreen('setting');
document.getElementById('btn-back-setting').onclick = () => showScreen('menu');
document.getElementById('btn-play').onclick = () => startGame();
document.getElementById('btn-quit').onclick = () => {
  gameRunning = false;
  showScreen('menu');
};
document.getElementById('btn-restart').onclick = () => startGame();
document.getElementById('btn-home').onclick = () => showScreen('menu');

// Âm thanh Web Audio đơn giản
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function playBeep(freq, duration = 0.15, type = 'sine') {
  if (!document.getElementById('sound-toggle').checked) return;
  if (audioCtx.state === 'suspended') audioCtx.resume();
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.start();
  gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
  osc.stop(audioCtx.currentTime + duration);
}

// ===== BIẾN GAME =====
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let gameRunning = false;
let timeLeft = 190; // 3 phút 10 giây = 190 giây
let lastTimestamp = 0;
let keys = {};

let killer = null;
let survivors = [];
let generators = [];
let obstacles = [];
let activeRepairGen = null;
let scPos = 0;
let scDir = 1;
let scTargetLeft = 110;

window.addEventListener('keydown', e => {
  keys[e.code] = true;
  if (!gameRunning) return;

  // Kỹ năng SPACE
  if (e.code === 'Space') {
    e.preventDefault();
    if (selectedRole === 'survivor') {
      const player = survivors.find(s => s.isPlayer);
      if (player && player.alive) triggerSurvivorBlock(player);
    } else {
      if (killer) triggerKillerAttack();
    }
  }

  // Mini-game Skill Check phím F
  if (e.code === 'KeyF' && activeRepairGen) {
    handleSkillCheckHit();
  }
});

window.addEventListener('keyup', e => {
  keys[e.code] = false;
});

canvas.addEventListener('mousedown', () => {
  if (gameRunning && selectedRole === 'killer') {
    triggerKillerAttack();
  }
});

// ===== KHỞI TẠO TRẬN ĐẤU =====
function startGame() {
  showScreen('game');
  document.getElementById('gameover-modal').classList.add('hidden');
  document.getElementById('minigame-modal').classList.add('hidden');
  activeRepairGen = null;

  timeLeft = 190; // 3:10
  const survCount = parseInt(document.getElementById('survivor-count').value, 10);

  // Vật cản trên bản đồ
  obstacles = [
    { x: 200, y: 120, w: 110, h: 30 },
    { x: 580, y: 120, w: 110, h: 30 },
    { x: 420, y: 240, w: 60, h: 80 },
    { x: 200, y: 410, w: 110, h: 30 },
    { x: 580, y: 410, w: 110, h: 30 }
  ];

  // 5 Trạm sửa chữa / Mini-game
  generators = [
    { id: 1, x: 110, y: 90, progress: 0, done: false },
    { id: 2, x: 790, y: 90, progress: 0, done: false },
    { id: 3, x: 450, y: 70, progress: 0, done: false },
    { id: 4, x: 110, y: 470, progress: 0, done: false },
    { id: 5, x: 790, y: 470, progress: 0, done: false }
  ];

  // Tạo Killer
  killer = {
    x: 450,
    y: 480,
    r: 18,
    baseSpeed: 165,
    isPlayer: selectedRole === 'killer',
    attackCooldown: 0,
    stunTimer: 0,
    swingAnim: 0
  };

  // Tạo Sờ Vai Vồ
  survivors = [];
  const spawnPoints = [
    { x: 120, y: 280 },
    { x: 780, y: 280 },
    { x: 450, y: 160 }
  ];

  for (let i = 0; i < survCount; i++) {
    survivors.push({
      id: i + 1,
      x: spawnPoints[i].x,
      y: spawnPoints[i].y,
      r: 15,
      hp: 3,
      alive: true,
      isPlayer: selectedRole === 'survivor' && i === 0,
      baseSpeed: 155,
      blockActiveTimer: 0,   // Thời gian đang bật khiên (1.2s)
      blockWasHit: false,
      speedBoostTimer: 0,    // +5s chạy nhanh nếu chặn thành công
      slowTimer: 0,          // -3s chạy chậm nếu Killer không đánh
      skillCooldown: 0
    });
  }

  gameRunning = true;
  lastTimestamp = performance.now();
  requestAnimationFrame(gameLoop);
}

// ===== KỸ NĂNG BLOCK CỦA SỜ VAI VỒ =====
function triggerSurvivorBlock(s) {
  if (s.skillCooldown > 0 || s.blockActiveTimer > 0 || !s.alive) return;
  s.blockActiveTimer = 1.2; // Bật khiên trong 1.2 giây
  s.blockWasHit = false;
  s.skillCooldown = 8.0;
  playBeep(520, 0.15, 'triangle');
}

// ===== ĐÒN ĐÁNH CỦA KILLER =====
function triggerKillerAttack() {
  if (killer.attackCooldown > 0 || killer.stunTimer > 0) return;
  killer.attackCooldown = 1.1;
  killer.swingAnim = 0.25;
  playBeep(180, 0.12, 'sawtooth');

  survivors.forEach(s => {
    if (!s.alive) return;
    const dist = Math.hypot(s.x - killer.x, s.y - killer.y);
    if (dist <= killer.r + s.r + 36) {
      if (s.blockActiveTimer > 0) {
        // CHẶN THÀNH CÔNG -> Sờ Vai Vồ nhận 5 giây chạy nhanh!
        s.blockActiveTimer = 0;
        s.blockWasHit = true;
        s.speedBoostTimer = 5.0;
        killer.stunTimer = 1.2;
        playBeep(880, 0.25, 'sine');
      } else {
        // Trúng đòn
        s.hp -= 1;
        s.speedBoostTimer = 1.2;
        playBeep(110, 0.25, 'square');
        if (s.hp <= 0) {
          s.alive = false;
          if (activeRepairGen && s.isPlayer) closeMiniGame();
        }
      }
    }
  });
}

// ===== MINI-GAME SỬA MÁY =====
function openMiniGame(gen) {
  activeRepairGen = gen;
  scPos = 0;
  scDir = 1;
  scTargetLeft = 60 + Math.random() * 130;
  document.getElementById('sc-target').style.left = scTargetLeft + 'px';
  document.getElementById('minigame-modal').classList.remove('hidden');
}

function closeMiniGame() {
  activeRepairGen = null;
  document.getElementById('minigame-modal').classList.add('hidden');
}

function handleSkillCheckHit() {
  if (!activeRepairGen) return;
  if (scPos >= scTargetLeft - 6 && scPos <= scTargetLeft + 55) {
    // Bấm trúng vùng xanh -> tăng nhanh tiến độ
    activeRepairGen.progress = Math.min(100, activeRepairGen.progress + 35);
    playBeep(700, 0.15, 'sine');
  } else {
    // Bấm trượt -> giảm nhẹ
    activeRepairGen.progress = Math.max(0, activeRepairGen.progress - 10);
    playBeep(150, 0.2, 'sawtooth');
  }
  scTargetLeft = 50 + Math.random() * 140;
  document.getElementById('sc-target').style.left = scTargetLeft + 'px';
}

function completeGenerator(gen) {
  if (gen.done) return;
  gen.done = true;
  gen.progress = 100;
  // Sửa xong 1 trò giảm 10 giây!
  timeLeft = Math.max(0, timeLeft - 10);
  playBeep(950, 0.35, 'triangle');
  if (activeRepairGen === gen) closeMiniGame();
}

// ===== VA CHẠM VẬT CẢN =====
function moveWithCollision(entity, dx, dy, dt) {
  let nx = entity.x + dx * dt;
  let ny = entity.y + dy * dt;

  nx = Math.max(entity.r + 8, Math.min(canvas.width - entity.r - 8, nx));
  ny = Math.max(entity.r + 8, Math.min(canvas.height - entity.r - 8, ny));

  if (!collidesObstacle(nx, entity.y, entity.r)) entity.x = nx;
  if (!collidesObstacle(entity.x, ny, entity.r)) entity.y = ny;
}

function collidesObstacle(x, y, r) {
  return obstacles.some(o =>
    x + r > o.x && x - r < o.x + o.w &&
    y + r > o.y && y - r < o.y + o.h
  );
}

// ===== VÒNG LẶP CẬP NHẬT =====
function update(dt) {
  timeLeft -= dt;
  if (timeLeft <= 0) {
    timeLeft = 0;
    endGame('SỜ VAI VỒ CHIẾN THẮNG!', 'Đã hết thời gian sinh tồn!');
    return;
  }

  // Kiểm tra toàn bộ Sờ Vai Vồ bị tiêu diệt
  const aliveSurvivors = survivors.filter(s => s.alive);
  if (aliveSurvivors.length === 0) {
    endGame('KILLER CHIẾN THẮNG!', 'Toàn bộ Sờ Vai Vồ đã bị tiêu diệt!');
    return;
  }

  // Cập nhật timers Killer
  if (killer.attackCooldown > 0) killer.attackCooldown -= dt;
  if (killer.stunTimer > 0) killer.stunTimer -= dt;
  if (killer.swingAnim > 0) killer.swingAnim -= dt;

  // Điều khiển / AI Killer
  if (killer.isPlayer) {
    if (killer.stunTimer <= 0) {
      let kx = 0, ky = 0;
      if (keys['KeyW'] || keys['ArrowUp']) ky -= 1;
      if (keys['KeyS'] || keys['ArrowDown']) ky += 1;
      if (keys['KeyA'] || keys['ArrowLeft']) kx -= 1;
      if (keys['KeyD'] || keys['ArrowRight']) kx += 1;
      if (kx !== 0 || ky !== 0) {
        const len = Math.hypot(kx, ky);
        moveWithCollision(killer, (kx / len) * killer.baseSpeed, (ky / len) * killer.baseSpeed, dt);
      }
    }
  } else {
    updateKillerAI(dt, aliveSurvivors);
  }

  // Cập nhật Sờ Vai Vồ
  survivors.forEach(s => {
    if (!s.alive) return;

    if (s.skillCooldown > 0) s.skillCooldown = Math.max(0, s.skillCooldown - dt);
    if (s.speedBoostTimer > 0) s.speedBoostTimer = Math.max(0, s.speedBoostTimer - dt);
    if (s.slowTimer > 0) s.slowTimer = Math.max(0, s.slowTimer - dt);

    // Xử lý hết thời gian Block
    if (s.blockActiveTimer > 0) {
      s.blockActiveTimer -= dt;
      if (s.blockActiveTimer <= 0) {
        s.blockActiveTimer = 0;
        // Nếu bật Block mà Killer KHÔNG đánh -> chạy chậm 3 giây!
        if (!s.blockWasHit) {
          s.slowTimer = 3.0;
          playBeep(220, 0.2, 'sawtooth');
        }
      }
    }

    // Tính tốc độ hiện tại
    let currentSpeed = s.baseSpeed;
    if (s.speedBoostTimer > 0) currentSpeed *= 1.45; // Chạy nhanh 5s
    if (s.slowTimer > 0) currentSpeed *= 0.55;       // Chạy chậm 3s

    if (s.isPlayer) {
      let sx = 0, sy = 0;
      if (keys['KeyW'] || keys['ArrowUp']) sy -= 1;
      if (keys['KeyS'] || keys['ArrowDown']) sy += 1;
      if (keys['KeyA'] || keys['ArrowLeft']) sx -= 1;
      if (keys['KeyD'] || keys['ArrowRight']) sx += 1;

      if (sx !== 0 || sy !== 0) {
        const len = Math.hypot(sx, sy);
        moveWithCollision(s, (sx / len) * currentSpeed, (sy / len) * currentSpeed, dt);
        if (activeRepairGen) closeMiniGame();
      }

      // Kiểm tra tương tác sửa máy phím E
      const nearGen = generators.find(g => !g.done && Math.hypot(g.x - s.x, g.y - s.y) < 48);
      if (nearGen && keys['KeyE']) {
        if (!activeRepairGen) openMiniGame(nearGen);
        nearGen.progress += 14 * dt;
        if (nearGen.progress >= 100) completeGenerator(nearGen);
      } else if (!nearGen && activeRepairGen) {
        closeMiniGame();
      }
    } else {
      updateSurvivorAI(s, dt, currentSpeed);
    }
  });

  // Cập nhật thanh con trỏ Mini-game
  if (activeRepairGen) {
    scPos += scDir * 240 * dt;
    if (scPos >= 254) { scPos = 254; scDir = -1; }
    if (scPos <= 0) { scPos = 0; scDir = 1; }
    document.getElementById('sc-cursor').style.left = scPos + 'px';
    document.getElementById('repair-percent').textContent = Math.floor(activeRepairGen.progress);
  }

  updateHUD();
}

// ===== AI BOT =====
function updateKillerAI(dt, aliveSurvivors) {
  if (killer.stunTimer > 0) return;
  const diff = document.getElementById('bot-difficulty').value;
  const mult = diff === 'easy' ? 0.78 : diff === 'hard' ? 1.05 : 0.92;

  // Tìm Sờ Vai Vồ gần nhất
  let target = aliveSurvivors[0];
  let minDist = Infinity;
  aliveSurvivors.forEach(s => {
    const d = Math.hypot(s.x - killer.x, s.y - killer.y);
    if (d < minDist) { minDist = d; target = s; }
  });

  if (target) {
    const angle = Math.atan2(target.y - killer.y, target.x - killer.x);
    moveWithCollision(
      killer,
      Math.cos(angle) * killer.baseSpeed * mult,
      Math.sin(angle) * killer.baseSpeed * mult,
      dt
    );
    if (minDist <= killer.r + target.r + 30) {
      triggerKillerAttack();
    }
  }
}

function updateSurvivorAI(s, dt, speed) {
  const distKiller = Math.hypot(killer.x - s.x, killer.y - s.y);

  // Nếu Killer lại gần, dùng Block hoặc bỏ chạy
  if (distKiller < 95) {
    if (s.skillCooldown <= 0 && distKiller < 58 && Math.random() < 0.08) {
      triggerSurvivorBlock(s);
    }
    const awayAngle = Math.atan2(s.y - killer.y, s.x - killer.x);
    moveWithCollision(s, Math.cos(awayAngle) * speed, Math.sin(awayAngle) * speed, dt);
    return;
  }

  // Tìm trạm máy gần nhất chưa sửa
  const undone = generators.filter(g => !g.done);
  if (undone.length > 0) {
    let targetGen = undone[0];
    let minD = Infinity;
    undone.forEach(g => {
      const d = Math.hypot(g.x - s.x, g.y - s.y);
      if (d < minD) { minD = d; targetGen = g; }
    });

    if (minD > 36) {
      const angle = Math.atan2(targetGen.y - s.y, targetGen.x - s.x);
      moveWithCollision(s, Math.cos(angle) * speed, Math.sin(angle) * speed, dt);
    } else {
      targetGen.progress += 12 * dt;
      if (targetGen.progress >= 100) completeGenerator(targetGen);
    }
  }
}

// ===== CẬP NHẬT HUD =====
function updateHUD() {
  const mins = Math.floor(timeLeft / 60);
  const secs = Math.floor(timeLeft % 60);
  document.getElementById('timer-display').textContent =
    `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

  const doneCount = generators.filter(g => g.done).length;
  document.getElementById('gen-display').textContent = `${doneCount}/${generators.length}`;

  if (selectedRole === 'survivor') {
    const p = survivors.find(s => s.isPlayer);
    document.getElementById('status-display').textContent = p && p.alive ? `${'❤️'.repeat(p.hp)}` : 'Đã bị hạ';
    if (p) {
      if (p.blockActiveTimer > 0) document.getElementById('skill-display').textContent = '🛡️ ĐANG BLOCK!';
      else if (p.speedBoostTimer > 0) document.getElementById('skill-display').textContent = `⚡ Chạy nhanh (${p.speedBoostTimer.toFixed(1)}s)`;
      else if (p.slowTimer > 0) document.getElementById('skill-display').textContent = `🐌 Chạy chậm (${p.slowTimer.toFixed(1)}s)`;
      else if (p.skillCooldown > 0) document.getElementById('skill-display').textContent = `Hồi chiêu (${p.skillCooldown.toFixed(1)}s)`;
      else document.getElementById('skill-display').textContent = 'Sẵn sàng';
    }
  } else {
    const aliveCount = survivors.filter(s => s.alive).length;
    document.getElementById('status-display').textContent = `Còn ${aliveCount} Sờ Vai Vồ`;
    document.getElementById('skill-display').textContent =
      killer.stunTimer > 0 ? '💫 Bị choáng!' :
      killer.attackCooldown > 0 ? `Hồi đòn (${killer.attackCooldown.toFixed(1)}s)` : 'Sẵn sàng chém';
  }
}

function endGame(title, desc) {
  gameRunning = false;
  closeMiniGame();
  document.getElementById('winner-title').textContent = title;
  document.getElementById('winner-desc').textContent = desc;
  document.getElementById('gameover-modal').classList.remove('hidden');
}

// ===== VẼ ĐỒ HỌA =====
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Lưới nền
  ctx.strokeStyle = '#1e2533';
  ctx.lineWidth = 1;
  for (let x = 0; x < canvas.width; x += 45) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
  }
  for (let y = 0; y < canvas.height; y += 45) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
  }

  // Vẽ vật cản
  ctx.fillStyle = '#334155';
  obstacles.forEach(o => {
    ctx.fillRect(o.x, o.y, o.w, o.h);
    ctx.strokeStyle = '#64748b';
    ctx.strokeRect(o.x, o.y, o.w, o.h);
  });

  // Vẽ các trạm sửa chữa
  generators.forEach(g => {
    ctx.beginPath();
    ctx.arc(g.x, g.y, 20, 0, Math.PI * 2);
    ctx.fillStyle = g.done ? '#22c55e' : '#eab308';
    ctx.fill();
    ctx.strokeStyle = '#fff';
    ctx.stroke();

    // Thanh tiến độ phía trên máy
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(g.x - 22, g.y - 32, 44, 6);
    ctx.fillStyle = g.done ? '#22c55e' : '#38bdf8';
    ctx.fillRect(g.x - 22, g.y - 32, 44 * (g.progress / 100), 6);
  });

  // Vẽ Sờ Vai Vồ
  survivors.forEach(s => {
    if (!s.alive) return;
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
    ctx.fillStyle = s.isPlayer ? '#38bdf8' : '#60a5fa';
    ctx.fill();

    // Vòng hiệu ứng Block / Tăng tốc / Làm chậm
    if (s.blockActiveTimer > 0) {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r + 7, 0, Math.PI * 2);
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 3;
      ctx.stroke();
    } else if (s.speedBoostTimer > 0) {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r + 5, 0, Math.PI * 2);
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 2;
      ctx.stroke();
    } else if (s.slowTimer > 0) {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r + 5, 0, Math.PI * 2);
      ctx.strokeStyle = '#a855f7';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    ctx.fillStyle = '#fff';
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(s.isPlayer ? 'Bạn' : `SVV ${s.id}`, s.x, s.y - 22);
  });

  // Vẽ Killer
  if (killer) {
    ctx.beginPath();
    ctx.arc(killer.x, killer.y, killer.r, 0, Math.PI * 2);
    ctx.fillStyle = '#ef4444';
    ctx.fill();

    if (killer.swingAnim > 0) {
      ctx.beginPath();
      ctx.arc(killer.x, killer.y, killer.r + 34, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.7)';
      ctx.lineWidth = 4;
      ctx.stroke();
    }

    ctx.fillStyle = '#fca5a5';
    ctx.font = 'bold 12px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(killer.isPlayer ? 'KILLER (Bạn)' : 'KILLER', killer.x, killer.y - 24);
  }
}

function gameLoop(timestamp) {
  if (!gameRunning) return;
  const dt = Math.min(0.05, (timestamp - lastTimestamp) / 1000);
  lastTimestamp = timestamp;
  update(dt);
  draw();
  requestAnimationFrame(gameLoop);
}


// Touch controls: map on-screen buttons to the same keys used by desktop controls.
document.querySelectorAll('#touch-controls [data-key]').forEach(button => {
  const key = button.dataset.key;
  const press = event => { event.preventDefault(); keys[key] = true; };
  const release = event => { event.preventDefault(); keys[key] = false; };
  button.addEventListener('pointerdown', press);
  button.addEventListener('pointerup', release);
  button.addEventListener('pointercancel', release);
  button.addEventListener('pointerleave', release);
});
